import { generate } from 'multiple-cucumber-html-reporter';

try {
  generate({
    jsonDir: 'test-results',
    reportPath: './',
    reportName: 'Playwright Automation Report',
    pageTitle: 'BookCart App test report',
    displayDuration: false,
    metadata: {
      browser: {
        name: 'chrome',
        version: '120',
      },
      device: 'Adam - PC',
      platform: {
        name: 'Windows',
        version: '11',
      },
    },
    customData: {
      title: 'Test Info',
      data: [
        { label: 'Project', value: 'BookCart App' },
        { label: 'Release', value: '1.2.3' },
        { label: 'Cycle', value: 'Smoke-1' },
      ],
    },
  });
  console.log('Report generated successfully.');
} catch (error) {
  console.error('Failed to generate report:', error);
}
