import { Given, When, Then, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { pageFixture } from '../../hooks/pageFixture';

setDefaultTimeout(60 * 10000 * 2);

Given('user search for a {string}', async function (book) {
  await pageFixture.page.locator('input[type="search"]').fill(book);
  await pageFixture.page.getByRole('option', { name: book }).click();
  await pageFixture.page.waitForLoadState();
  //await pageFixture.page.locator('mat-option[role="option"] span').click();
});

When('user add the book to the cart', async function () {
  await pageFixture.page.waitForSelector('//button[contains(@class, "mdc-button--raised") and contains(@class, "mat-primary") and contains(@class, "mat-mdc-button-base") and .//span[contains(text(), "Add to Cart")]]');
  await pageFixture.page.locator('//button[contains(@class, "mdc-button--raised") and contains(@class, "mat-primary") and contains(@class, "mat-mdc-button-base") and .//span[contains(text(), "Add to Cart")]]').click();
  await pageFixture.page.waitForLoadState();
  await pageFixture.page.waitForTimeout(5000); 
});

Then('the cart badge should get updated with {string}', async function (book) {
  await pageFixture.page.waitForLoadState();
  await pageFixture.page.waitForSelector('//button[@mat-icon-button and .//mat-icon[contains(text(), "shopping_cart")]]');
  await pageFixture.page.locator('//button[@mat-icon-button and .//mat-icon[contains(text(), "shopping_cart")]]').click();
  
  // Verify the table with rows is available
  await pageFixture.page.waitForSelector('//table[@role="table"]//tr');
  const bookInCart = await pageFixture.page.getByRole('cell', { name: book }).textContent();
  expect(bookInCart).toContain(book);
  
  // Clear the cart
  await pageFixture.page.waitForSelector('//button[contains(@class, "mdc-button--raised") and .//span[contains(text(), "Clear cart")]]');
  await pageFixture.page.locator('//button[contains(@class, "mdc-button--raised") and .//span[contains(text(), "Clear cart")]]').click();
  
  // Verify the cart is empty
  const emptyCartMessage = await pageFixture.page.locator('mat-card-header').filter({ hasText: 'Your shopping cart is empty.' }).textContent();
  expect(emptyCartMessage).toContain('Your shopping cart is empty.');
});


