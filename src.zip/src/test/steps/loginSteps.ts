import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { pageFixture } from '../../hooks/pageFixture';
import fs from 'fs-extra';

async function initializeTestResultsFolder() {
  try {
    await fs.ensureDir('test-results');
    await fs.emptyDir('test-results');
    console.log('Test results folder initialized.');
  } catch (error) {
    console.error('Folder not created!', error);
  }
}



initializeTestResultsFolder();

Given('User navigates to the application', async function () {
  await pageFixture.page.goto('https://bookcart.azurewebsites.net/');
});

Given('User click on the login link', async function () {
  await pageFixture.page.locator('mat-toolbar-row').getByRole('button', { name: 'Login' }).click();
});


Given('User enter the username as {string}', async function (username) {
  await pageFixture.page.getByPlaceholder('Username').click();
  await pageFixture.page.getByPlaceholder('Username').fill(username);
});

Given('User enter the password as {string}', async function (password) {
  await pageFixture.page.getByPlaceholder('Password').click();
  await pageFixture.page.getByPlaceholder('Password').fill(password);
  await pageFixture.page.getByPlaceholder('Password').press('Tab');
});

When('User click on the login button', async function () {
  await pageFixture.page.locator('//button[@color="primary" and span/text()="Login"]').click();
  await pageFixture.page.waitForSelector('//a[contains(span/span, "ortoni")]');
  await pageFixture.page.waitForLoadState();
  await pageFixture.page.waitForTimeout(5000);
});

Then('Login should be success', async function () {
  
  expect(pageFixture.page.waitForSelector('//a[contains(span/span, "ortoni")]'));
  await pageFixture.page.waitForLoadState();
  await pageFixture.page.waitForTimeout(5000);
});

Then('Login should fail', async function () {
  //system remains in same login page
   const errorMessage = pageFixture.page.locator('//button[@color="primary" and span/text()="Login"]');
   await expect(errorMessage).toBeVisible();
});
