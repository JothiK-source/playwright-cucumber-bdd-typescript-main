declare module 'multiple-cucumber-html-reporter' {
  export function generate(options: unknown): void;
}